player_manager.AddValidModel("A REDMAN", "models/sheepylord/REDMAN/a_REDMAN_pm.mdl");
player_manager.AddValidHands("A REDMAN", "models/sheepylord/REDMAN/a_REDMAN_arms.mdl" , 0, "000000")

local Category = "REDMAN"

local NPC = {
    Name = "A REDMAN (Friendly)",
    Class = "npc_citizen",
    Model = "models/sheepylord/REDMAN/a_REDMAN.mdl",
    Health = "100",
    KeyValues = { citizentype = 4 },
    Weapons = { "weapon_smg1" },
    Category = Category
}

list.Set("NPC", "a_REDMAN_sheepylord_F", NPC)

local NPC = {
    Name = "A REDMAN (Enemy)",
    Class = "npc_combine_s",
    Model = "models/sheepylord/REDMAN/a_REDMAN.mdl",
    Health = "100",
    Numgrenades = "4",
    Weapons = { "weapon_ar2" },
    Category = Category
}

list.Set("NPC", "a_REDMAN_sheepylord_E", NPC)
